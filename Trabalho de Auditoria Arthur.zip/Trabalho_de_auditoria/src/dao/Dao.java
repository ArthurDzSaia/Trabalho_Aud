package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


import banco.ConexaoMysql;
import modelo.Cadastro;

public class Dao {
	
	private Connection con;
	private ConexaoMysql conexao;
	
	public Dao() {
		this.conexao = ConexaoMysql.getInstancia();
		this.con = conexao.conecta();
		}
	
	public void insert(Cadastro user) {
		String sql = "insert into cadastro "
		 + "(nome, email, telefone) values (?, ?, ?)";
		try {
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, user.getNome());
		stmt.setString(2, user.getEmail());
		stmt.setString(3, user.getTelefone());


		stmt.execute();
		stmt.close();
		}catch (SQLException e) {
		throw new RuntimeException(e);
		}
	}
		
}